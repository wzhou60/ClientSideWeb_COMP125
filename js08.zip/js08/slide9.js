let employee = {
    name: "Ronnell Jones",
    position: "manager"
 };
 let prop = "name";
 console.log(employee[prop]);
 