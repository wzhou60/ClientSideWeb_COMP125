let cardGame = {
  title: "Draw Poker",
  createdBy: "Ronnell Jones",
  lastRevised: null,
  programmers: ["Tom Devlan", "Chanda Bhasin"],
};

console.log(cardGame.title);

console.log(cardGame["title"]);
