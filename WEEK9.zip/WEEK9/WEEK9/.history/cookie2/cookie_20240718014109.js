let username = "Desmond Jennings";
let nameCode = encodeURIComponent(username);
let maxAge = 60*60*24*365;
document.cookie = "name=" + nameCode + ";max-age=" + maxAge;
console.log(document.cookie)