let username = "Desmond Jennings";
let nameCode = encodeURIComponent(username);
let document.cookie = "name=" + nameCode;
