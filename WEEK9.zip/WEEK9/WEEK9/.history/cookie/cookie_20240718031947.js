let username = "Desmond Jennings";
let nameCode = encodeURIComponent(username);
lrt document.cookie = "name=" + nameCode;
