let day 
if (day === "Friday") {
  window.alert("Get ready for the Weekend!");
}
