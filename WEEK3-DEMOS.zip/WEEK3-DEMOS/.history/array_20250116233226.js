//slide 4
let newSection = ["world", "local", "opinion", "sports"];
document.write(newSection);
//OR