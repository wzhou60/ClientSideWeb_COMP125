let day = "Tuesday";
