let day = "Tuesday";
if (day === "Friday") {
  window.alert("Get ready for the Weekend!");
} else {
  window.alert("Have a great day!");
}
