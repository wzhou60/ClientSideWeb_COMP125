let username = "Desmond Jennings";
let nameCode = encodeURIComponent(username);
document.cookie = "name=" + nameCode;
