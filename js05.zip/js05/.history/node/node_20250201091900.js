/*
// Get the container element
const container = document.getElementById("container");

// Use node.firstChild to get the first child of the container
const firstChild = container.firstChild;

// Log the first child node (which will be a text node, because of whitespace before the first <p>)
console.log(firstChild);

// To get the first element child (ignoring text nodes), we can use firstElementChild
const firstElementChild = container.firstElementChild;
console.log(firstElementChild);

// Display the first child element in the browser
document.body.insertAdjacentHTML(
  "beforeend",
  `<p>The first element child is: ${firstElementChild.innerHTML}</p>`
);
*/

document.addEventListener("DOMContentLoaded", () => {
  // Get the container element
  const element = document.getElementById("container");
  if (element) {
    // Use node.firstChild to get the first child of the element and log it in the console
    console.log(element.firstChild);
  }
  // To get the first element child (ignoring text nodes), we can use firstElementChild
  const firstElementChild = element.firstElementChild;
  console.log(firstElementChild);

  //--------------------------------------------------
  //lastChild
  if (element) {
    console.log(element.lastChild);
  }

  const lastElementChild = element.lastElementChild;
  console.log(lastElementChild);

  //node.childNodes;
    console.log(element.childNodes);
    console.loh()
});
