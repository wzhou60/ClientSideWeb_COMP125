/*
// Get the container element
const container = document.getElementById("container");

// Use node.firstChild to get the first child of the container
const firstChild = container.firstChild;

// Log the first child node (which will be a text node, because of whitespace before the first <p>)
console.log(firstChild);

// To get the first element child (ignoring text nodes), we can use firstElementChild
const firstElementChild = container.firstElementChild;
console.log(firstElementChild);

// Display the first child element in the browser
document.body.insertAdjacentHTML(
  "beforeend",
  `<p>The first element child is: ${firstElementChild.innerHTML}</p>`
);
*/

document.addEventListener("DOMContentLoaded", () => {
  const element = document.getElementById("container");
  if (element) {
    console.log(element.firstChild);
    }
  const firstElementChild = element.firstElementChild;
    console.log(firstElementChild);
    
    if (element) {
      console.log(element.lastChild);
    }

    
});
