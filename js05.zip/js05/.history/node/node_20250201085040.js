// Get the container element
const container = document.getElementById("container");

// Use node.firstChild to get the first child of the container
const firstChild = container.firstChild;

// Log the first child node (which will be a text node, because of whitespace before the first <p>)
console.log(firstChild);

