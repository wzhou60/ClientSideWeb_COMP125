let socialSecurityNumber = 123-45-6789";
let checkVar = isNaN(socialSecurityNumber);
document.write(checkVar);
