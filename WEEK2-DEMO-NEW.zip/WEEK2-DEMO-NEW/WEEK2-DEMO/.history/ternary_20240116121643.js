age = 20;
var status = (age >= 18) ? "adult" : "minor"; 
console.log(status)