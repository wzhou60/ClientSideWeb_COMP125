var fg = document.getElementById("submit");
fg.onclick = 
document.getElementById("submit").addEventListener("click",)