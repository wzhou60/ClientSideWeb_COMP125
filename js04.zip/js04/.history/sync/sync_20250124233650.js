<button onclick="sayHello()">Click me</button>
    <script>
        function sayHello() {
   let message = "Hello World";
   window.alert(message);
        }
        </script>
