<button onclick="sayHello()">Click me</button>
    <>
        function sayHello() {
   let message = "Hello World";
   window.alert(message);
        }
