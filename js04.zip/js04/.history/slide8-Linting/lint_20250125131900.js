// Go he jslint.com and paste the code
