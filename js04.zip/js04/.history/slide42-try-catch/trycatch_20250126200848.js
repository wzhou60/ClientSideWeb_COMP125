let userName = "Jenkins";
try {
    userName = prompt()
  window.alert("The user is " + userName);
} catch (err) {
  window.alert("Invalid code");
}
