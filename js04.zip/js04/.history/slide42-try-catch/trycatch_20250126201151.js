//let userName = "Jenkins";
userName = prompt("please enter your name");
try {
    if (userName === "Jenkins")
  window.alert("The user is " + userName);
} catch (err) {
  window.alert("Invalid code");
}
