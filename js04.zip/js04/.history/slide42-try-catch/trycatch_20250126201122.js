//let userName = "Jenkins";
userName = prompt("please enter your name");
try {
  window.alert("The user is " + userName);
} catch (err) {
  window.alert("Invalid code");
}
