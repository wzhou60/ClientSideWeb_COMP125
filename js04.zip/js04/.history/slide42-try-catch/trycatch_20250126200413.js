let userName = "Jenkins";
try {
  window.alert("The user is " + username);
} catch (err) {
  window.alert("Invalid code");
}
