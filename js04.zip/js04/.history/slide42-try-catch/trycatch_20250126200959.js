
let userName = "Jenkins";
try {
  
  window.alert("The user is " + userName);
} catch (err) {
  window.alert("Invalid code");
}
