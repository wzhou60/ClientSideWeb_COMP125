let userName = "Jenkins";
try {
    userName = prompt("please enter your name");
  window.alert("The user is " + userName);
} catch (err) {
  window.alert("Invalid code");
}
