let userName = "Jenkins";
try {
    user
  window.alert("The user is " + userName);
} catch (err) {
  window.alert("Invalid code");
}
