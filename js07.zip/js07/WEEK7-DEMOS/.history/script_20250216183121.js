let farr = "First Inaugural Address".indexOf(" "); 
console.log