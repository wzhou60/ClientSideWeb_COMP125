let farr = "First Inaugural Address".indexOf(" "); 
consol