//slide8
//indexOf
let arr = "First Inaugural Address";
let farr = arr.indexOf(" ");
console.log(farr);

//lastIndexOf
let larr = arr.lastIndexOf(" ");
console.log(larr);

//slides12
let charat = "Abraham Lincoln".charAt(4); // returns "h"
console.log(charat);

//slide13
//slice
"Abraham Lincoln".slice(4,10) // "ham Li"
"Abraham Lincoln".substring(4,10) // "ham Li"
"Abraham Lincoln".substr(4,10) // "ham Licoln"
