let arr = "First Inaugural Address";
let farr = "First Inaugural Address".indexOf(" ");
console.log(farr);
