//slide8
//indexOf
let arr = "First Inaugural Address";
let farr = arr.indexOf(" ");
console.log(farr);

//lastIndexOf
let larr = arr.lastIndexOf(" ");
console.log(larr);

//slides12
let charat = "Abraham Lincoln".charAt(4); // returns "h"
console.log(charat);

//slide13
//slice
let sli = "Abraham Lincoln".slice(4, 10); // "ham Li"
console.log(sli);
//substring
let sub = "Abraham Lincoln".substring(4, 10); // "ham Li"
console.log(sub);
// substr
let substr = "Abraham Lincoln".substr(4, 10); // "ham Licoln"
console.log(substr);

//slice-backward
let sliceback = "Abraham Lincoln".slice(-7, -3); // "Linc"
console.log(sliceback);
//substring - backward
let substringback = "Abraham Lincoln".substring(-7); // "Abraham Lincoln"
console.log(substringback);
// substr - backward
let substrback = "Abraham Lincoln".substr(-7, 4); // "Linc"
console.log(substrback);

//slide14
let email = "lincoln@example.com";
let atIndex = email.indexOf("@"); // returns 7
email.slice(0, atIndex); // returns "lincolnemail.slice(atIndex + 1); // returns "example.com"
