//slide8
//indexOf
let arr = "First Inaugural Address";
let farr = arr.indexOf(" ");
console.log(farr);

//lastIndexOf
let larr = arr.lastIndexOf(" ");
console.log(larr);

//slides12
let charat = "Abraham Lincoln".charAt(4); // returns "h"
console.log(charat);

//slide13
//slice
let sli = "Abraham Lincoln".slice(4, 10) // "ham Li"
console.log(sli);
//substring
let sub = "Abraham Lincoln".substring(4, 10) // "ham Li"
console.log(sub);
// substr
let substr = "Abraham Lincoln".substr(4, 10) // "ham Licoln"
console.log()
