//slide8
//indexOf
let arr = "First Inaugural Address";
let farr = arr.indexOf(" ");
console.log(farr);

//lastIndexOf
let larr = arr.lastIndexOf(" ");
console.log(larr);

//slides