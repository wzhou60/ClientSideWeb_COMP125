//slide 19
//Sample for loop:
for (let i = 1; i <= 5; i++) {
  document.write(i + "<br>");
}
