//slide 4
/*let newSection = ["world", "local", "opinion", "sports"];
document.write(newSection);
*/

//OR
//-----------------------------------
/*let newSection = new Array(4);
newSection[0] = "world";
newSection[1] = "local";
newSection[2] = "opinion";
newSection[3] = "sports";
document.write(newSection);
*/

//slide5

let newSection = ["world", "local", "opinion", "sports"];
//document.write(newSection);

newSection[4] = "Entertainment";
document.write(newSection);

newSection.length;
