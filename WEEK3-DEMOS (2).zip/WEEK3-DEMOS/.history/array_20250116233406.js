//slide 4
let newSection = ["world", "local", "opinion", "sports"];
document.write(newSection);
//OR

let newSection = new Array(3);
newSection[0] = "world";
newSection[1] = "local";
newSection[2] = "opinion";