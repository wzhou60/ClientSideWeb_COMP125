//slide 4
/*let newSection = ["world", "local", "opinion", "sports"];
document.write(newSection);
*/

//OR
//-----------------------------------
/*let newSection = new Array(4);
newSection[0] = "world";
newSection[1] = "local";
newSection[2] = "opinion";
newSection[3] = "sports";
document.write(newSection);
*/

//slide5
/*
let newSection = ["world", "local", "opinion", "sports"];
//document.write(newSection);

newSection[4] = "Entertainment";
document.write(newSection);

ghj = newSection.length;
console.log(ghj);
*/

//slide24 & 25

let x = [1, 3, 5, 10];
x.forEach(stepUp5);
function stepUp5(arrValue, i, arr) {
  arr[i] = arrValue + 5;
}