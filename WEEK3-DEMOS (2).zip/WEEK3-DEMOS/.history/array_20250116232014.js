let newSection = ["world", "local", "opinion", "sports"]
 