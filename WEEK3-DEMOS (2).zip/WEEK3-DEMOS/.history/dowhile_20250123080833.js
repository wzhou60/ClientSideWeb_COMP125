var count = 2;
do {
   document.write("<p>The count is equal to " +↵
      count + ".</p>");
   count++;
} while (count < 2);
