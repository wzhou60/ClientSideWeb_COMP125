for (var count = 1; count <= 5; count++) {
  if (count === 3) {
    continue;
  }
  document.write("<p>" + count + "</p>");
}
